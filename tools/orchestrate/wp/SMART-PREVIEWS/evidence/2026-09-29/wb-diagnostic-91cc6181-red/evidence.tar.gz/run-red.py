import os,json,subprocess,pathlib,hashlib,shutil,re
P=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/Users/rutmehta/.codex/worktrees/proxy-wb-diagnostic/tessera');REF='91cc6181a0a5d11de4a85441a3f5afc6c5deed50'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def freeze():
 return {'head':git('rev-parse','HEAD'),'status':git('status','--porcelain'),'source':{n:sha(R/n) for n in subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=R).decode().split('\0') if n},'runner':sha(pathlib.Path(__file__)),'fixture_scope':'none: pure synthetic only; no ignored/actual/GPU tests','artifacts':{n:sha(p) for n,p in artifacts.items()}}
artifacts={};assert git('rev-parse','HEAD')==REF and not git('status','--porcelain')
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_'))};env.pop('RAW_DECODE_FIXTURES',None);env.update(CARGO_TARGET_DIR='/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated',CARGO_BUILD_JOBS='2',MACOSX_DEPLOYMENT_TARGET='15.0',RAYON_NUM_THREADS='2')
def run(name,cmd,expected):
 d=P/name;d.mkdir();b=freeze();save(d/'before.json',b);save(d/'command.json',{'argv':cmd,'cwd':str(R),'env':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','MACOSX_DEPLOYMENT_TARGET','RAYON_NUM_THREADS']},'TESSERA_flags_scrubbed':True})
 with (d/'run.log').open('w') as f:code=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 (d/'exit').write_text(str(code)+'\n');a=freeze();save(d/'after.json',a);save(d/'freeze.json',{'equal':a==b,'direct_exit':code});assert a==b
 assert code in expected,f'{name}: unexpected direct exit {code}; stop'
 return (d/'run.log').read_text()
log=run('01-default-feature-graph',['cargo','tree','--locked','-e','normal','--prefix','none','--format','{p} features={f}','-p','tessera-ffi'],[0]);assert 'wb-diagnostic' not in log;assert 'image-core v' in log
for i,(package,target) in enumerate([('image-core','image_core'),('tessera-ffi','tessera_ffi')],2):
 log=run(f'{i:02d}-compile-{target}',['cargo','test','--locked','--jobs','2','-p',package,'--lib','--release','--features','wb-diagnostic','--no-run','--message-format=json-render-diagnostics'],[0])
 ex=[]
 for line in log.splitlines():
  try:o=json.loads(line)
  except ValueError:continue
  if o.get('reason')=='compiler-artifact' and o.get('target',{}).get('name')==target and o.get('executable'):ex.append(o['executable'])
 assert len(set(ex))==1
 copy=P/(target+'-test');shutil.copy2(ex[0],copy);artifacts[target]=copy;save(P/'artifacts.json',{n:{'path':str(p),'sha256':sha(p)} for n,p in artifacts.items()})
for i,(target,pattern,total,ignored) in enumerate([('image_core','wb_diagnostic::tests',10,0),('tessera_ffi','wb_diagnostic_contracts',3,4)],4):
 log=run(f'{i:02d}-red-{target}',[str(artifacts[target]),pattern,'--test-threads=1','--nocapture'],[101]);m=re.search(r'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;',log);assert m;passed,failed,skipped=map(int,m.groups());assert passed+failed==total and skipped==ignored
 save(P/f'{i:02d}-red-{target}'/'observed.json',{'passed':passed,'failed':failed,'ignored':skipped,'scope':'Manual Unsupported boundary review required; table rows after first failure remain unexecuted'})
print('Bounded pure RED complete; no implementation or actual-phase qualification.')
