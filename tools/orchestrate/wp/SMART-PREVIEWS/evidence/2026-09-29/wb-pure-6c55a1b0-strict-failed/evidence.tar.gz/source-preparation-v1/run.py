#!/usr/bin/env python3
"""Prepared only. Requires coordinator exclusive runtime grant."""
import argparse, hashlib, json, os, pathlib, re, subprocess, time
ROOT=pathlib.Path('/Users/rutmehta/.codex/worktrees/proxy-wb-diagnostic/tessera')
OUT=pathlib.Path(__file__).parent
HEAD='6c55a1b0471c87c740be39f8a7ea0337a7c6321b'
ENV={'CARGO_TARGET_DIR':'/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MACOSX_DEPLOYMENT_TARGET':'15.0'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def freeze():
 names=git('ls-files','-z','--cached','--others','--exclude-standard').split('\0')
 return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain'),'source':{n:sha(ROOT/n) for n in names if n and (ROOT/n).is_file()},'runner':sha(pathlib.Path(__file__)),'oracle':sha(OUT/'required-tests.json'),'fixture_scope':'none: pure synthetic contracts; four actual placeholders excluded'}
p=argparse.ArgumentParser();p.add_argument('phase',choices=['compile-image','compile-ffi','green-image','green-ffi','strict','fmt','default-features']);p.add_argument('--attempt',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
package='image-core' if a.phase.endswith('image') else 'tessera-ffi'
cmd=None
if a.phase.startswith('compile-'):cmd=['cargo','test','--locked','--jobs','2','-p',package,'--release','--features','wb-diagnostic','--lib','--no-run','--message-format=json-render-diagnostics']
if a.phase=='strict':cmd=['cargo','clippy','--locked','--jobs','2','-p','image-core','-p','tessera-ffi','--release','--features','image-core/wb-diagnostic,tessera-ffi/wb-diagnostic','--all-targets','--','-D','warnings']
if a.phase=='fmt':cmd=['cargo','fmt','--all','--','--check']
if a.phase=='default-features':cmd=['cargo','tree','--locked','-p','image-core','-p','tessera-ffi','-e','features']
if not a.execute:
 print(json.dumps({'phase':a.phase,'argv':cmd or ['<exact compiled executable>','<pure module filter>','--test-threads=1','--nocapture','<four exact actual placeholder skips>'],'env':ENV,'state':'PREPARED; no freeze/workload'}));raise SystemExit(0)
assert re.fullmatch(r'[0-9][A-Za-z0-9_-]*',a.attempt)
d=OUT/a.attempt;d.mkdir(exist_ok=False);b=freeze();save(d/'before.json',b);assert b['head']==HEAD and not b['status']
oracle=json.loads((OUT/'required-tests.json').read_text());artifact=None
if a.phase.startswith('green-'):
 artifact=json.loads((OUT/(package+'-artifact.json')).read_text());assert artifact['head']==HEAD and sha(pathlib.Path(artifact['path']))==artifact['sha256'];assert b==json.loads((OUT/artifact['compile_attempt']/'after.json').read_text());save(d/'artifact-before.json',artifact)
 cmd=[artifact['path'],'wb_diagnostic::tests::' if package=='image-core' else 'wb_diagnostic_contracts::','--test-threads=1','--nocapture']
 if package=='tessera-ffi':
  for n in oracle['excluded_actual']:cmd+=['--skip',n]
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_')) and k not in ['RAW_DECODE_FIXTURES','PIPELINE_RAW_FIXTURES','IMAGE_CORE_ALL_FIXTURES','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']};env.update(ENV)
save(d/'command.json',{'argv':cmd,'cwd':str(ROOT),'env':ENV,'test_fixture_flags_scrubbed':True})
start=time.monotonic()
with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
(d/'exit').write_text(str(r.returncode)+'\n');after=freeze();save(d/'after.json',after);save(d/'freeze.json',{'equal':b==after,'direct_exit':r.returncode,'elapsed_seconds':time.monotonic()-start});assert b==after
log=(d/'run.log').read_text()
if a.phase.startswith('compile-') and r.returncode==0:
 records=[]
 for line in log.splitlines():
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if v.get('reason')=='compiler-artifact' and v.get('executable') and v.get('target',{}).get('name')==package.replace('-','_') and v.get('profile',{}).get('test'):records.append(v)
 assert len(records)==1
 exe=pathlib.Path(records[0]['executable']);save(OUT/(package+'-artifact.json'),{'head':HEAD,'compile_attempt':a.attempt,'path':str(exe),'sha256':sha(exe)})
if a.phase.startswith('green-'):
 current={**artifact,'sha256':sha(pathlib.Path(artifact['path']))};save(d/'artifact-after.json',current);assert current==artifact
 names=re.findall(r'^test (\S+) \.\.\.',log,re.M);expected=oracle[package];save(d/'observed.json',{'names':names,'summaries':re.findall(r'test result:.*',log),'direct_exit':r.returncode})
 assert sorted(names)==sorted(expected)
 if r.returncode==0:assert f'test result: ok. {len(expected)} passed; 0 failed; 0 ignored;' in log
if a.phase=='default-features' and r.returncode==0:assert 'wb-diagnostic' not in log,'diagnostic feature leaked into default graph'
raise SystemExit(r.returncode)
