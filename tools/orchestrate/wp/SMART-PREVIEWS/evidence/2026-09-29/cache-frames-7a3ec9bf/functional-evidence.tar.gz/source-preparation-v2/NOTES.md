# Task 3 source-only qualification package

No runtime, compiler, app, GPU workload, or candidate timing has run. The two patches have passed read-only `git apply --check` against their exact bases. Scoped rustfmt parsed/formatted temporary Rust sources; Python AST parsing checked runner syntax only. These are not compilation or execution evidence.

## Exact composition and ownership

- Baseline product: immutable `3614e21bee508563432a9d235964b76e3c43a02f`, plus `baseline.patch` (only existing test-only `preview_qualification.rs` module declaration and new test-only harness file). No baseline backend/product source changes. Its cache/calibration telemetry is explicitly **null**, not invented zero counts. Source checks compare every base Git blob plus the exact overlay hashes.
- Candidate product: functionally qualified `7faea4b8e7a3bdc46afcf794a9e4dc5c6710be6c`, plus `candidate.patch`. Adds the same harness and cfg(test,macOS) real-auto selector observation / copied key fingerprint. `ObserveAuto` preserves the actual environment preference and real calibration; no fake measurement or forced winner is allowed in performance runs. Other product behavior is unchanged.
- Original frozen baseline checkout and qualified candidate checkout remain untouched. The coordinator must provide a separate baseline-composition checkout and a committed candidate-composition checkout after review. Do not apply the baseline patch to the frozen baseline worktree.
- `source-manifest.json` pins both base refs and every overlay file. `run.py` requires clean committed exact compositions, rejects any other tracked or untracked nonignored source change, builds retained separate lib-test executables, and hashes both executables before/after every process. Alternate retained binaries directly; never alternate Cargo rebuilds inside timing trials.
- This package is a proposal requiring independent review before build/workload. Compilation shape and actual assertions remain UNRUN. No new public FFI or rollout/default switch.

## Functional stage (before performance)

Six processes: for SDR then EDR, baseline CPU reference, candidate controlled-CPU winner, candidate controlled-Metal winner. Each uses a disposable copy of the explicit Sony fixture, builds Compact, performs one initial and five same-Engine unchanged opens, renders matching-generation FINAL frames into actual owned IOSurfaces, then exposure/WB edits, mapped-geometry CPU fallback and restored resident capability. Selection samples are controlled only in the two candidate functional routes; frames themselves are real. No timing benefit is claimed from this stage.

Candidate counters must show one initial measurement/publication and five exact-key hits with **zero further calibration**, full key fingerprints equal, no recipe/journal/proxy/original mutation. Actual per-frame resident receipts, submissions, and zero timed pixel readback establish execution separately from backend labels. A CPU winner still creates a GPU candidate for capability; its Weak is drained even though its actual frames are CPU. No `weak_gpu.is_some()==selectedMetal` shortcut hides this candidate.

Each measured row is written before route/pixel/drain assertions. Listener entry timestamps, not channel dequeue time, define delivery. Pixel extraction/file writes/comparisons are after timing. Every cycle clears instrumentation strong references and checks WeakShared/Renderer/GPU plus IOSurface disappearance within5s. Final Engine drop is also bounded/reported. These are owned-resource observations, not global RSS/driver cache claims.

Warm edits use full typed settings, do not commit, and restore the exact initial settings with a matching final frame before close. The existing recipe/journal/proxy/source hash assertions then prove no inadvertent save. Geometry is tested only in the functional stage; it is not mixed into speed ratios.

## Performance preregistration

A=baseline, B=candidate. Exactly five pairs per output format: **AB, BA, AB, BA, AB**, process sequence **ABBAABBAAB**. First A of SDR and EDR is collected as stability preflight before any B performance process. The remaining nine processes of each format then follow that fixed relative order. Add one baseline CPU reference process per format:22 total performance processes. Each process has one initial open, five unchanged reopens, two warm edit probes, and an untimed-for-acceptance restore frame.

All performance selectors are actual auto; inherited TESSERA flags are scrubbed. No controlled timing or forced backend enters these ratios. Baseline CV must be<=20% within every five-reopen cohort and in the pooled baseline cohort; mixed backend/level/dimension/settings cohorts are explicitly inconclusive. Both variants must have matching cohorts before timing ratios are calculated. Different-source-size speed claims are excluded.

For each format, compare median of25 reopen samples per variant (five processes×five reopens). Require>=20% **and** >=20ms improvement. Compare five initial-open samples per variant; allowed regression<=max(10ms,5% baseline median). Compare five warm exposure and five warm WB samples independently; each allowed regression<=max(2ms,10%). Per-process samples and medians remain in raw records; no p95 or population guarantee.

Numeric bounds are copied unchanged from the accepted baseline preregistration: SDR channel absolute<=4/255; EDR<=0.002+0.002×abs(CPU reference). Comparable settings, delivered dimensions/levels and display dimensions are mandatory. EDR above-white content remains required. All baseline/candidate output frames and edits are compared against the matching CPU reference outside measured intervals. An incomparable cohort is inconclusive; numerical failure is failure, not a tolerance adjustment.

Metric is public open through matching final IOSurface listener delivery and edit request through such delivery. It includes the actual open/first-frame work and reports both components. It is **not** physical display latency or a cold-filesystem benchmark. Calibration removal also removes warm cache work; a faster open return alone cannot pass the combined gate.

## Commands after separate grant

Supply newly prepared committed composition checkouts; these placeholders must not point at the frozen baseline.

```text
python3 run.py --execute --stage build --baseline <baseline-composition> --candidate <candidate-composition> --fixture /Volumes/betterSSD/tessera-validation/m258-current/visible-run-f1d13c11/fixture/sony-arw.ARW --out <new-build-evidence>
python3 run.py --execute --stage functional --baseline <baseline-composition> --candidate <candidate-composition> --fixture <same-fixture> --artifacts <build-evidence> --out <new-functional-evidence>
python3 run.py --execute --stage performance --functional <matching-passed-functional-evidence> --baseline <baseline-composition> --candidate <candidate-composition> --fixture <same-fixture> --artifacts <build-evidence> --out <new-performance-evidence>
```

Every build pins `CARGO_TARGET_DIR=/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated`, jobs2 and `MACOSX_DEPLOYMENT_TARGET=15.0`. Every process preserves source/artifact/fixture/runner before-after, direct exit, full log and command. Performance refuses to start without a passed functional verdict over these exact source/runner/fixture/artifact hashes. Failed child processes retain their after snapshot; previous evidence directories cannot be overwritten. RAW originals are read-only; edits/builds operate only on disposable copies. Binary/RGB buffers are host-local evidence classes, not candidates for a portable text bundle.


## Source review response, revision 2

The reviewer correctly identified that deriving frame expectation only from the
observed selected backend would allow a wrong controlled winner to qualify itself.
Each controlled CPU/Metal cycle now independently asserts the requested winner
against the actual backend, after persisting its measured row. Existing resident
receipt/submission/readback checks remain separate. Actual-auto performance uses
no forced expected winner; common-cohort and measured execution gates remain.

Build commands now include Cargo `--locked`. The dependency lockfile is also part
of the exact source composition/freeze. No workload was run; v1 remains preserved
in the durable evidence directory, with this revision awaiting rereview.
