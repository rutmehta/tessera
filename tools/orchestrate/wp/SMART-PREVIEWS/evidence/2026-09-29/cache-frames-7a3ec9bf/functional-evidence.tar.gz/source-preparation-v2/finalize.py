from pathlib import Path
import json,hashlib,subprocess,difflib
P=Path(__file__).parent;ROOT=Path('/Users/rutmehta/.codex/worktrees/export-integration/tessera');m=json.loads((P/'source-manifest.json').read_text())
for v in ('baseline','candidate'):
 patch='';hashes={}
 for p in sorted((P/v).rglob('*.rs')):
  name=str(p.relative_to(P/v));s=p.read_text();result=subprocess.run(['git','show',f'{m[v+"_base"]}:{name}'],cwd=ROOT,capture_output=True);old=result.stdout.decode() if result.returncode==0 else ''
  patch+=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+name if result.returncode==0 else '/dev/null',tofile='b/'+name))
  hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 (P/(v+'.patch')).write_text(patch);m['overlays'][v]=hashes
(P/'source-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
