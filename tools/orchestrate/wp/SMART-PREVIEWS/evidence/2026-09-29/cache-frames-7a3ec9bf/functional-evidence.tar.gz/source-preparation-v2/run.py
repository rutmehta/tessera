#!/usr/bin/env python3
"""Preregistered qualification only. Requires independent review + exclusive lane grant."""
import argparse,array,hashlib,json,os,pathlib,re,shutil,statistics,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--execute',action='store_true');p.add_argument('--stage',choices=['build','functional','performance'],required=True)
p.add_argument('--baseline',required=True);p.add_argument('--candidate',required=True);p.add_argument('--fixture',required=True)
p.add_argument('--functional',help='matching passed functional evidence required before performance')
p.add_argument('--out',required=True);p.add_argument('--artifacts',help='existing build stage directory for functional/performance')
a=p.parse_args()
if not a.execute: sys.exit('No workload authorized by preparation. --execute requires exclusive runtime grant.')
roots={v:pathlib.Path(getattr(a,v)).resolve() for v in ('baseline','candidate')}
fixture=pathlib.Path(a.fixture).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
manifest=json.loads((P/'source-manifest.json').read_text());limits=json.loads((P/'thresholds.json').read_text())
def save(p,obj): p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def source(root):
 names=git(root,'ls-files','-z','--cached','--others','--exclude-standard').decode().split('\0')
 return {'head':git(root,'rev-parse','HEAD').decode().strip(),'status':git(root,'status','--porcelain').decode(),
         'files':{n:sha(root/n) for n in names if n and (root/n).is_file()}}
def base_hashes(root,ref):
 entries=git(root,'ls-tree','-r','-z',ref).split(b'\0');spec=[]
 for entry in entries:
  if not entry:continue
  meta,name=entry.split(b'\t',1);_,kind,oid=meta.split()
  assert kind==b'blob', 'unexpected non-file base entry'
  spec.append((name.decode(),oid))
 proc=subprocess.run(['git','cat-file','--batch'],cwd=root,input=b'\n'.join(oid for _,oid in spec)+b'\n',capture_output=True,check=True)
 data=proc.stdout;at=0;result={}
 for name,oid in spec:
  end=data.index(b'\n',at);header=data[at:end].split();assert header[0]==oid and header[1]==b'blob';size=int(header[2]);at=end+1
  result[name]=hashlib.sha256(data[at:at+size]).hexdigest();at+=size+1
 assert at==len(data);return result
def verify_composition(variant):
 root=roots[variant];actual=source(root);assert not actual['status'], 'apply/commit reviewed overlay before execution'
 expected=base_hashes(root,manifest[variant+'_base']);expected.update(manifest['overlays'][variant])
 assert actual['files']==expected, f'{variant}: source differs from exact base plus reviewed test overlay'
 return actual
assert sha(fixture)==limits['fixture_sha256']
inputs={v:verify_composition(v) for v in roots}
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_'))};env.pop('RAW_DECODE_FIXTURES',None)
env.update(CARGO_TARGET_DIR='/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated',CARGO_BUILD_JOBS='2',MACOSX_DEPLOYMENT_TARGET='15.0')
knobs={k:v for k,v in env.items() if k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','MACOSX_DEPLOYMENT_TARGET','RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTUP_TOOLCHAIN','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']}
runner_files={n:sha(P/n) for n in ['run.py','source-manifest.json','thresholds.json']}
artifact_paths={}
def freeze():return {'sources':{v:source(root) for v,root in roots.items()},'fixture_sha256':sha(fixture),'runner_files':{n:sha(P/n) for n in runner_files},'artifacts':{v:sha(path) for v,path in artifact_paths.items()}}
before=freeze();save(out/'before.json',before);save(out/'thresholds.json',limits);save(out/'environment.json',knobs)
def invoke(dest,argv,cwd,process_env):
 dest.mkdir();save(dest/'before.json',freeze());save(dest/'command.json',{'argv':argv,'cwd':str(cwd),'env':knobs|{k:v for k,v in process_env.items() if k.startswith('TESSERA_')}})
 start=time.monotonic();code=None
 try:
  with (dest/'run.log').open('w') as log: code=subprocess.run(argv,cwd=cwd,env=process_env,stdout=log,stderr=subprocess.STDOUT).returncode
  (dest/'exit').write_text(str(code)+'\n')
 finally:
  after=freeze();save(dest/'after.json',after);save(out/'after.json',after)
  save(dest/'freeze.json',{'equal':before==after,'elapsed_seconds':time.monotonic()-start,'direct_exit':code})
 assert before==after,'frozen inputs changed'
 assert code==0,f'direct failure preserved: {dest}'
 return (dest/'run.log').read_text(errors='replace')
TEST='engine_proxy_cache_frame_qualification'
if a.stage=='build':
 records={}
 for v in ('baseline','candidate'):
  d=out/('build-'+v)
  cmd=['cargo','test','--locked','-p','tessera-ffi','--lib','--release',TEST,'--no-run','--message-format=json-render-diagnostics']
  log=invoke(d,cmd,roots[v],env)
  exes=[]
  for line in log.splitlines():
   try:obj=json.loads(line)
   except ValueError:continue
   if obj.get('reason')=='compiler-artifact' and obj.get('executable') and obj.get('profile',{}).get('test') and obj.get('target',{}).get('name')=='tessera_ffi':exes.append(obj['executable'])
  assert len(set(exes))==1,exes
  exe=out/(v+'-test');shutil.copy2(exes[0],exe)
  records[v]={'path':str(exe),'sha256':sha(exe),'source':inputs[v]}
 save(out/'artifacts.json',{'records':records,'runner_files':runner_files,'environment':knobs});print('Two retained test artifacts built; no frame or timing acceptance.');sys.exit(0)
assert a.artifacts,'retained build artifacts required'
artifacts=json.loads((pathlib.Path(a.artifacts)/'artifacts.json').read_text())
assert artifacts['runner_files']==runner_files and artifacts['environment']==knobs
for v,record in artifacts['records'].items():assert record['source']==inputs[v] and sha(pathlib.Path(record['path']))==record['sha256']
artifact_paths={v:pathlib.Path(record['path']) for v,record in artifacts['records'].items()}
before=freeze();save(out/'before.json',before)
if a.stage=='performance':
 assert a.functional,'matching actual-frame functional evidence required'
 prior=pathlib.Path(a.functional);verdict=json.loads((prior/'verdict.json').read_text())
 assert verdict.get('functional') is True and verdict.get('performance') is False
 assert json.loads((prior/'before.json').read_text())==before,'functional evidence uses different inputs/artifacts'
runs=[]
def run(label,variant,fmt,route='proxy-auto',selector='actual'):
 record=artifacts['records'][variant];exe=pathlib.Path(record['path']);assert sha(exe)==record['sha256']
 dest=out/label
 flags={'TESSERA_QUALIFY_ROUTE':route,'TESSERA_QUALIFY_FORMAT':fmt,'TESSERA_QUALIFY_OUT':str(dest),
  'TESSERA_SMART_PREVIEW_RAW':str(fixture),'TESSERA_RENDER_BACKEND':'cpu' if route=='proxy-cpu' else '',
  'TESSERA_QUALIFY_SELECTOR':selector,'TESSERA_QUALIFY_PHASE':a.stage}
 log=invoke(dest,[str(exe),TEST,'--ignored','--nocapture','--test-threads=1'],roots[variant],env|flags)
 assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',log), 'actual ignored test was not executed'
 assert sha(exe)==record['sha256'],'binary changed during run'
 save(dest/'artifact.json',{'path':str(exe),'sha256':record['sha256']})
 data=json.loads((dest/'reopen-results.json').read_text());rows=data['rows'];edits=data['edits']
 assert data['variant']==variant and data['selector']==selector and data['engine_count']==1 and len(rows)==6
 assert [r['cycle'] for r in rows]==list(range(6))
 assert all(r['released'] and r['release_ms']<5000 and r['pixel_readback_bytes']==0 for r in rows)
 assert json.loads((dest/'engine-release.json').read_text())['released']
 assert all(e['pixel_readback_bytes']==0 for e in edits)
 assert {e['label'] for e in edits}==({'exposure','white_balance','restored','mapped_geometry'} if a.stage=='functional' else {'exposure','white_balance','restored'})
 def cohort(row):return (row['backend'],row['resident'],row['level'],row['dimensions'],row['display_dimensions'],row['settings'],row['format'])
 stable=all(cohort(r)==cohort(rows[0]) for r in rows)
 values=[r['open_to_final_callback_ms'] for r in rows[1:]]
 cv=statistics.pstdev(values)/statistics.fmean(values) if stable else None
 summary={'label':label,'variant':variant,'format':fmt,'selector':selector,'route':route,'cohort_stable':stable,'cv':cv,
  'initial_ms':rows[0]['open_to_final_callback_ms'],'reopen_median_ms':statistics.median(values),
  'rows':rows,'edits':edits,'directory':str(dest)}
 runs.append(summary);save(out/'runs.json',runs)
 return summary
def inconclusive(condition, reason):
 if not condition:
  save(out/'verdict.json',{'status':'inconclusive','performance':False,'reason':reason});raise AssertionError(reason)
def assert_stable(record):inconclusive(record['cohort_stable'] and record['cv']<=limits['performance']['baseline_cv_max'], 'baseline unstable; no performance acceptance')
def comparable(a,b):return all(a[k]==b[k] for k in ['level','dimensions','display_dimensions','settings'])
def pixel_values(directory,row):
 values=array.array('f');values.frombytes((pathlib.Path(directory)/row['pixel_file']).read_bytes())
 if sys.byteorder!='little':values.byteswap()
 assert len(values)==row['dimensions'][0]*row['dimensions'][1]*3
 return values
comparisons=[]
def compare(record,reference):
 pairs=[(r,reference['rows'][r['cycle']]) for r in record['rows']]
 refs={e['label']:e for e in reference['edits']};pairs += [(e,refs[e['label']]) for e in record['edits']]
 for row,ref in pairs:
  match=comparable(row,ref);entry={'run':record['label'],'frame':row.get('label',row.get('cycle')),'comparable':match}
  if match:
   actual=pixel_values(record['directory'],row);expected=pixel_values(reference['directory'],ref)
   errors=[abs(x-y) for x,y in zip(actual,expected,strict=True)]
   entry['max_absolute_error']=max(errors)
   bound=limits['fidelity'];fmt=record['format']
   entry['passed']=all(error <= (bound['sdr_max_absolute_per_channel'] if fmt=='sdr' else bound['edr_absolute']+bound['edr_relative']*abs(y)) for error,y in zip(errors,expected,strict=True))
   if fmt=='edr' and row.get('label')!='mapped_geometry':entry['above_white']=any(x>1 for x in actual);entry['passed'] &= entry['above_white']
  comparisons.append(entry);save(out/'fidelity.json',comparisons)
  assert match and entry['passed'],'geometry/fidelity failed; no speed ratio acceptance'
if a.stage=='functional':
 for fmt in ('sdr','edr'):
  ref=run('cpu-reference-'+fmt,'baseline',fmt,'proxy-cpu')
  for selector in ('controlled-cpu','controlled-metal'):
   got=run(selector+'-'+fmt,'candidate',fmt,selector=selector);compare(got,ref)
 save(out/'verdict.json',{'functional':True,'performance':False,'processes':len(runs),'comparisons':len(comparisons)})
 print('Actual frames/lifecycle/fidelity qualified; controlled samples provide no performance claim.');sys.exit(0)
# First A of each format is the baseline stability preflight, before ANY B timing.
first={fmt:run('pair0-A-'+fmt,'baseline',fmt) for fmt in ('sdr','edr')}
for record in first.values():assert_stable(record)
by_format={}
sequence=limits['performance']['pair_sequence']
for fmt in ('sdr','edr'):
 ordered=[first[fmt]]
 for index,variant in enumerate(sequence[1:],1):
  got=run(f'pair{index//2}-{variant}-{fmt}', 'baseline' if variant=='A' else 'candidate',fmt)
  if variant=='A':assert_stable(got)
  ordered.append(got)
 reference=run('cpu-reference-'+fmt,'baseline',fmt,'proxy-cpu')
 for record in ordered:compare(record,reference)
 A=[r for r in ordered if r['variant']=='baseline'];B=[r for r in ordered if r['variant']=='candidate'];assert len(A)==len(B)==5
 all_rows=[row for r in ordered for row in r['rows']]
 contract=lambda r:(r['backend'],r['resident'],r['level'],r['dimensions'],r['display_dimensions'],r['settings'])
 inconclusive(all(contract(row)==contract(all_rows[0]) for row in all_rows),'mixed output/backend cohort; no speedup claim')
 values=lambda group:[row['open_to_final_callback_ms'] for r in group for row in r['rows'][1:]]
 av,bv=values(A),values(B);cv=statistics.pstdev(av)/statistics.fmean(av)
 inconclusive(cv<=limits['performance']['pooled_baseline_cv_max'],'pooled baseline unstable; inconclusive')
 am,bm=statistics.median(av),statistics.median(bv)
 initialA,initialB=statistics.median(r['initial_ms'] for r in A),statistics.median(r['initial_ms'] for r in B)
 perf=limits['performance'];absolute=am-bm;relative=absolute/am
 result={'baseline_reopen_median_ms':am,'candidate_reopen_median_ms':bm,'relative_improvement':relative,'absolute_improvement_ms':absolute,'baseline_cv':cv,
  'reopen_pass':relative>=perf['reopen_min_relative_improvement'] and absolute>=perf['reopen_min_absolute_improvement_ms'],
  'initial_baseline_ms':initialA,'initial_candidate_ms':initialB,'initial_pass':initialB<=initialA+max(perf['initial_absolute_ms'],perf['initial_relative']*initialA),'warm_edits':{}}
 for label in ('exposure','white_balance'):
  med=lambda group:statistics.median(next(e['edit_to_final_callback_ms'] for e in r['edits'] if e['label']==label) for r in group)
  x,y=med(A),med(B);result['warm_edits'][label]={'baseline_ms':x,'candidate_ms':y,'passed':y<=x+max(perf['warm_edit_absolute_ms'],perf['warm_edit_relative']*x)}
 result['passed']=result['reopen_pass'] and result['initial_pass'] and all(v['passed'] for v in result['warm_edits'].values())
 by_format[fmt]=result;save(out/'performance.json',by_format)
assert all(v['passed'] for v in by_format.values()),'preregistered benefit/regression gate failed; preserve accepted behavior'
save(out/'verdict.json',{'functional_fidelity':True,'performance':True,'processes':len(runs),'scope':'one machine/copied Sony, callback delivery; not cold filesystem or physical display'})
print('Bounded preregistered benefit gates passed; broader rollout remains coordinator decision.')
