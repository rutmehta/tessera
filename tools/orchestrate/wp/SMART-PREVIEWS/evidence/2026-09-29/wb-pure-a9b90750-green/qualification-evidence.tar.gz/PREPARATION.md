# WB pure final-source qualification — PREPARED, UNRUN

Pinned a9b9075071b9267e442899798770800fbf082db0. Runner identical to reviewed6c55v2 except exactHEAD; required19pure testoracle unchanged. Previous6c55compile/GREEN/strictfailure and all91ccRED evidence retained untouched. BorrowedFrameOutput grouping independently source-approved; no measurementbody or fourcallvalue changes.

After separate exclusive runtime grant, sequentially stop on unexpectedfailure:

python3 run.py compile-image --attempt 01-compile-image --execute
python3 run.py compile-ffi --attempt 02-compile-ffi --execute
python3 run.py green-image --attempt 03-green-image --execute
python3 run.py green-ffi --attempt 04-green-ffi --execute
python3 run.py strict --attempt 05-strict --execute
python3 run.py fmt --attempt 06-fmt --execute
python3 run.py default-features --attempt 07-default-features --execute

16imagecore+3FFIpure, fouractualplaceholder names explicitlyskipped. Twofeaturecompiles/exactbinaries; featureenabledalltargetClippy forbothcrates; workspacefmt; actualfeaturefield-onlydefaultgraphcheck. Exactsource/runner/oracle/binary beforeafter+directexits retained. BetterSSDtarget/jobs2/deployment15, flags scrubbed. No actualfixture/frame/GPU/app/benchmark/livewiring or performance acceptance. Sourcepreparation/ASTparse only, noexecution.
