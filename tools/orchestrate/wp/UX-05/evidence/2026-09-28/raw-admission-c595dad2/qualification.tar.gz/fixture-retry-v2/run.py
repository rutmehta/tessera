#!/usr/bin/env python3
"""Source-only preparation. --execute requires a separate coordinator runtime grant."""
import argparse, hashlib, json, os, pathlib, re, subprocess, time
ROOT=pathlib.Path('/Users/rutmehta/.codex/worktrees/raw-render-admission/tessera')
OUT=pathlib.Path(__file__).parent
HEAD='c595dad26b2180e9e89cf63d43dcca46e50252b9'
ENV={'CARGO_TARGET_DIR':'/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MACOSX_DEPLOYMENT_TARGET':'15.0'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def inputs():return {str(p):sha(p) for p in [pathlib.Path(__file__),OUT/'required-tests.json',OUT/'baseline.json',OUT/'formatting-proof.json']}
def snapshot():
 names=git('ls-files','-z','--cached','--others','--exclude-standard').split('\0')
 # Default full-suite external discovery. Absence is recorded, never called fixture coverage.
 dirs=[ROOT/'fixtures/raw',ROOT/'tools/orchestrate/wp/M3-05/.cache']
 extras={str(d):{'exists':d.exists(),'files':{str(p):sha(p) for p in sorted(d.rglob('*')) if p.is_file()} if d.exists() else {}} for d in dirs}
 return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain'),'source':{n:sha(ROOT/n) for n in names if n and (ROOT/n).is_file()},'external_discovery':extras,'qualification_inputs':inputs()}
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['compile','focused','full','strict','fmt']);parser.add_argument('--attempt',required=True);parser.add_argument('--execute',action='store_true');a=parser.parse_args()
base=['cargo','test','--locked','--jobs','2','-p','image-core','--release']
commands={'compile':base+['--lib','raw_admission::tests','--no-run'],'focused':None,'full':base+['--','--test-threads=1','--nocapture'],'strict':['cargo','clippy','--locked','--jobs','2','-p','image-core','--all-targets','--release','--','-D','warnings'],'fmt':['cargo','fmt','--all','--','--check']}
if not a.execute:
 print(json.dumps({'state':'PREPARED ONLY; no execution','phase':a.phase,'command':commands[a.phase] or 'exact compiled executable from artifact.json','env':ENV}));raise SystemExit(0)
assert re.fullmatch(r'[0-9][A-Za-z0-9_-]*',a.attempt)
d=OUT/a.attempt;d.mkdir(exist_ok=False)
b=snapshot();save(d/'before.json',b);baseline=json.loads((OUT/'baseline.json').read_text());assert b['head']==HEAD and not b['status'];assert b['source']==baseline['source'];assert b['external_discovery']==baseline['external_discovery']
env={k:v for k,v in os.environ.items() if not k.startswith('TESSERA_') and k not in ['RAW_DECODE_FIXTURES','PIPELINE_RAW_FIXTURES','IMAGE_CORE_ALL_FIXTURES']};env.update(ENV)
cmd=commands[a.phase];artifact=None
if a.phase=='focused':
 artifact=json.loads((OUT/'artifact.json').read_text());assert artifact['head']==HEAD;assert sha(pathlib.Path(artifact['path']))==artifact['sha256'];save(d/'artifact-before.json',artifact)
 cmd=[artifact['path'],'raw_admission::tests','--test-threads=1','--nocapture']
save(d/'command.json',{'argv':cmd,'cwd':str(ROOT),'env':ENV,'fixture_and_TESSERA_overrides_scrubbed':True})
start=time.monotonic()
with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
(d/'exit').write_text(str(r.returncode)+'\n');after=snapshot();save(d/'after.json',after);save(d/'freeze.json',{'equal':b==after,'direct_exit':r.returncode,'elapsed_seconds':time.monotonic()-start});assert b==after
log=(d/'run.log').read_text();expected=r.returncode==0
if a.phase=='compile' and expected:
 paths=re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)',log);assert len(paths)==1
 p=pathlib.Path(paths[0]);save(OUT/'artifact.json',{'head':HEAD,'path':str(p),'sha256':sha(p),'compile_attempt':a.attempt})
if artifact:
 current={**artifact,'sha256':sha(pathlib.Path(artifact['path']))};save(d/'artifact-after.json',current);assert current==artifact
if a.phase=='focused':
 names=json.loads((OUT/'required-tests.json').read_text());results={n:re.findall(r'^test '+re.escape(n)+r' \.\.\. ok$',log,re.M) for n in names};save(d/'required-results.json',results)
 expected=expected and all(len(v)==1 for v in results.values()) and '20 passed; 0 failed; 0 ignored;' in log
save(d/'result.json',{'expected':expected,'phase':a.phase,'direct_exit':r.returncode,'summaries':re.findall(r'test result:.*',log),'scope':'pure admission + existing affected suite; no renderer/provenance/full native-memory acceptance'})
raise SystemExit(0 if expected else 1)
