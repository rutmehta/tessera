# Task1 qualification runner — PREPARED, UNEXECUTED

Pinned 0434ff8d, no Task2 delegation. Commands, after exclusive runtime grant only:

    python3 run.py compile --attempt 01-compile --execute
    python3 run.py green --attempt 02-green --execute
    python3 run.py full --attempt 03-full --execute
    python3 run.py strict --attempt 04-strict --execute
    python3 run.py fmt --attempt 05-fmt --execute

Run serially, stop on any unexpected failure. Cargo test/clippy use --locked, jobs2, explicit shared BetterSSD target and macOS15. Environment scrubs TESSERA/RUST_TEST/fixture overrides. Exact selected executable is hashed before/after GREEN; all17 mandatory names must pass with no ignores. Every phase preserves direct exit/log and full source/runner/oracle/fixture before/after freeze. No freeze or workload has run during preparation.

Full raw-decode uses RAW_DECODE_FIXTURES explicitly pointing to the existing main five-family fixture directory, with exact names/bytes/hashes from accepted closed-decoder fixture-env.json checked before/after. This avoids the RAW checkout's DNG-only default directory, which cannot satisfy existing fixtures_decode. No copies/writes to photos. The normal full suite covers the existing five-family legacy fixture test; explicitly ignored captured-decoder qualification remains ignored and is NOT claimed. Fixture hashing is deferred to the runtime grant. No GPU/apps/benchmark. RED remains intact in sibling bf75fe66 directory.
