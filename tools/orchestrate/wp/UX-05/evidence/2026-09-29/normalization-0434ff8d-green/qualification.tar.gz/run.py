#!/usr/bin/env python3
"""Prepared only. Execution needs coordinator's exclusive runtime grant."""
import argparse, hashlib, json, os, pathlib, re, subprocess, time
ROOT=pathlib.Path('/Users/rutmehta/.codex/worktrees/raw-render-admission/tessera')
OUT=pathlib.Path(__file__).parent
HEAD='0434ff8d412d19f1ba1b841b15799d0aa621f4b8'
ENV={'CARGO_TARGET_DIR':'/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MACOSX_DEPLOYMENT_TARGET':'15.0'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def fixtures():
 spec=json.loads((OUT/'fixture-env.json').read_text()); folder=pathlib.Path(spec['directory'])
 names={p.name for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ['.arw','.cr3','.nef','.raf','.dng']}
 assert names==set(spec['files']), 'fixture inventory changed'
 got={n:{'path':v['path'],'bytes':pathlib.Path(v['path']).stat().st_size,'sha256':sha(pathlib.Path(v['path']))} for n,v in spec['files'].items()}
 assert got==spec['files'], 'fixture identity changed'
 return got
def freeze():
 names=git('ls-files','-z','--cached','--others','--exclude-standard').split('\0')
 return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain'),'source':{n:sha(ROOT/n) for n in names if n and (ROOT/n).is_file()},'runner':sha(pathlib.Path(__file__)),'oracle':sha(OUT/'required-tests.json'),'fixture_spec':sha(OUT/'fixture-env.json'),'fixtures':fixtures()}
p=argparse.ArgumentParser();p.add_argument('phase',choices=['compile','green','full','strict','fmt']);p.add_argument('--attempt',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
cmd=['cargo','test','--locked','--jobs','2','-p','raw-decode','--release','--lib','normalize::tests','--no-run'] if a.phase=='compile' else None
if a.phase=='full':cmd=['cargo','test','--locked','--jobs','2','-p','raw-decode','--release','--','--test-threads=1','--nocapture']
if a.phase=='strict':cmd=['cargo','clippy','--locked','--jobs','2','-p','raw-decode','--release','--all-targets','--','-D','warnings']
if a.phase=='fmt':cmd=['cargo','fmt','--all','--','--check']
if not a.execute:
 print(json.dumps({'phase':a.phase,'argv':cmd or ['<exact compiled executable>','normalize::tests','--test-threads=1','--nocapture'],'env':ENV,'state':'PREPARED; freeze/workload deferred until grant'}));raise SystemExit(0)
assert re.fullmatch(r'[0-9][A-Za-z0-9_-]*',a.attempt)
d=OUT/a.attempt;d.mkdir(exist_ok=False)
b=freeze();save(d/'before.json',b);assert b['head']==HEAD and not b['status']
artifact=None
if a.phase=='green':
 artifact=json.loads((OUT/'artifact.json').read_text());assert artifact['head']==HEAD;assert sha(pathlib.Path(artifact['path']))==artifact['sha256'];assert b==json.loads((OUT/artifact['compile_attempt']/'after.json').read_text());save(d/'artifact-before.json',artifact)
 cmd=[artifact['path'],'normalize::tests','--test-threads=1','--nocapture']
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_')) and k not in ['RAW_DECODE_FIXTURES','PIPELINE_RAW_FIXTURES','IMAGE_CORE_ALL_FIXTURES']};env.update(ENV)
if a.phase=='full':env['RAW_DECODE_FIXTURES']=json.loads((OUT/'fixture-env.json').read_text())['directory']
save(d/'command.json',{'argv':cmd,'cwd':str(ROOT),'env':{**ENV,**({'RAW_DECODE_FIXTURES':env['RAW_DECODE_FIXTURES']} if a.phase=='full' else {})},'TESSERA_test_fixture_overrides_scrubbed':True})
start=time.monotonic()
with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
(d/'exit').write_text(str(r.returncode)+'\n');after=freeze();save(d/'after.json',after);save(d/'freeze.json',{'equal':b==after,'direct_exit':r.returncode,'elapsed_seconds':time.monotonic()-start});assert b==after
log=(d/'run.log').read_text()
if a.phase=='compile':
 if r.returncode:raise SystemExit(r.returncode)
 paths=re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)',log);assert len(paths)==1
 exe=pathlib.Path(paths[0]);save(OUT/'artifact.json',{'head':HEAD,'compile_attempt':a.attempt,'path':str(exe),'sha256':sha(exe)})
elif a.phase=='green':
 current={**artifact,'sha256':sha(pathlib.Path(artifact['path']))};save(d/'artifact-after.json',current);assert artifact==current
 names=json.loads((OUT/'required-tests.json').read_text());observed=re.findall(r'^test (normalize::tests::\w+) \.\.\.',log,re.M);assert len(observed)==17 and set(observed)==set(names)
 summaries=re.findall(r'test result:.*',log);save(d/'observed.json',{'direct_exit':r.returncode,'names':observed,'summaries':summaries,'classification':'Focused exact-binary GREEN requires all17 named tests passed'})
 assert 'test result: ok. 17 passed; 0 failed; 0 ignored;' in log, 'focused GREEN not established'
else:
 save(d/'observed.json',{'direct_exit':r.returncode,'summaries':re.findall(r'test result:.*',log)})
 if a.phase=='full' and r.returncode==0:
  names=json.loads((OUT/'required-tests.json').read_text())
  assert all(f'test {n} ... ok' in log for n in names)
  assert 'test fixture_tests::fixtures_decode ...' in log and not 'skipping RAW fixture tests' in log
raise SystemExit(r.returncode)
