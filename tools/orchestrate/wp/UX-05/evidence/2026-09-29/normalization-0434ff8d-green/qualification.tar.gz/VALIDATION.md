# Normalization Task1 qualification

Exact source `0434ff8d412d19f1ba1b841b15799d0aa621f4b8`: compile01, exact-binary17-test GREEN02, full raw-decode03, strict all-target Clippy04 and workspace formatting05 all direct exit0. No source repairs between gates. All ten source/runner/oracle/fixture freezes match (9140 source entries).

Full suite: {'passed': 88, 'failed': 0, 'ignored': 2}; all17 normalization contracts and existing five-family fixtures_decode passed. Five named existing originals are hashed before/after, matching the accepted decoder fixture manifest. Full uses explicit RAW_DECODE_FIXTURES at the main fixture directory; ignored captured-decoder qualification tests were not run. No new native decode-route coverage is claimed.

Exact test executable SHA256 `7acccf26e21f6d42d05ba1144f5d1c7ff31e59ed9967f61ae5a51e58bf1ca8b0`; matching before/after and rehashed at report time. See FINAL-CHECKPOINT.json, direct exits/full logs, command records and per-run freezes.

Prior17Unsupported RED at bf75fe66 is preserved unchanged in the sibling directory. Only the private cfg(test) Task1 helper is qualified; existing legacy linearize/public behavior remain unchanged, Task2 delegation has not started. No allocation-cap/RSS/provenance/renderer claim. Runtime explicitly released to root immediately after final gate.
