# Task2 final qualification — PREPARED, UNEXECUTED

Pin: 2d7c00fa11700b61e681349f5130663e6325f33d. After exclusive runtime grant only, serially:

    python3 run.py compile --attempt 01-compile --execute
    python3 run.py green --attempt 02-green --execute
    python3 run.py full --attempt 03-full --execute
    python3 run.py strict --attempt 04-strict --execute
    python3 run.py fmt --attempt 05-fmt --execute

Stop on unexpected failure. Compile --locked/jobs2/release, then exact hashed executable filtered normalize::, requiring all21 named tests pass/no ignores. Full raw-decode runs existing unit/integration/doc tests; integrations compile the library without cfg(test), exercising the production helper path. Strict alltargets and workspace fmt check follow. No added tests.

Explicit shared BetterSSD target/macOS15; test environment overrides scrubbed. Full sets existing main five-family RAW_DECODE_FIXTURES. Five source-original identities copied from accepted decoder manifest are verified before/after, with exact required directory inventory. Ignored captured-decoder qualification tests remain unrun. No photo copies/edits, GPU/apps or performance claims. Every phase preserves source/runner/oracle/fixture freeze, commands/direct exits/logs; exact focused executable before/after hash. Existing Task1 and Task2 RED evidence remains unchanged. Preparation validates Python syntax only; no source/fixture freeze, hashing workload or gate execution until grant.
