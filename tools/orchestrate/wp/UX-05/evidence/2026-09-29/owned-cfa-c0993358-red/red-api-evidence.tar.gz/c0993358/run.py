#!/usr/bin/env python3
"""Source-only preparation. Explicit coordinator runtime grant required."""
import argparse,hashlib,json,os,pathlib,re,subprocess,time
ROOT=pathlib.Path('/Users/rutmehta/.codex/worktrees/raw-render-admission/tessera')
OUT=pathlib.Path(__file__).parent
HEAD='c099335882b0e677d75d6069a1079e789e7efaad'
TARGET='/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated'
ENV={'CARGO_TARGET_DIR':TARGET,'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MACOSX_DEPLOYMENT_TARGET':'15.0'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True)
def freeze():
 names=git('ls-files','-z','--cached','--others','--exclude-standard').split('\0')
 return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain'),'source':{n:sha(ROOT/n) for n in names if n and (ROOT/n).is_file()},'runner':sha(pathlib.Path(__file__)),'oracle':sha(OUT/'required-tests.json'),'api_oracle':sha(ROOT/'crates/raw-decode/tests/owned_api/expectations.json'),'fixtures':'none; five protocol tests use synthetic private temp bytes; no actual five-family qualification'}
def artifact_context():
 path=OUT/'artifacts.json'
 if not path.exists():return None
 a=json.loads(path.read_text());assert a['head']==HEAD
 return {n:sha(pathlib.Path(n)) for n in a['dependency_context']}
def run(d,cmd,env):
 d.mkdir(exist_ok=False);start_inputs={'source':freeze(),'dependencies':artifact_context()};save(d/'inputs-before.json',start_inputs);save(d/'command.json',{'argv':cmd,'cwd':str(ROOT),'env':ENV});t=time.monotonic()
 with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 (d/'exit').write_text(str(r.returncode)+'\n');save(d/'timing.json',{'elapsed_seconds':time.monotonic()-t});end_inputs={'source':freeze(),'dependencies':artifact_context()};save(d/'inputs-after.json',end_inputs);assert start_inputs==end_inputs;return r.returncode,(d/'run.log').read_text()
p=argparse.ArgumentParser();p.add_argument('phase',choices=['compile','red','api']);p.add_argument('--attempt',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
compile_cmd=['cargo','test','--locked','--jobs','2','-p','raw-decode','--release','--tests','--no-run','--message-format=json-render-diagnostics']
if not a.execute:
 print(json.dumps({'state':'PREPARED, no freeze or workload','phase':a.phase,'argv':compile_cmd if a.phase=='compile' else '<exact unit binary / downstream rustc positive then eight intended negatives>','env':ENV}));raise SystemExit(0)
assert re.fullmatch(r'[0-9][A-Za-z0-9_-]*',a.attempt)
d=OUT/a.attempt;d.mkdir(exist_ok=False);b=freeze();save(d/'before.json',b);assert b['head']==HEAD and not b['status']
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_')) and k not in ['RAW_DECODE_FIXTURES','PIPELINE_RAW_FIXTURES','IMAGE_CORE_ALL_FIXTURES','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']};env.update(ENV)
save(d/'rustc-version.json',{'text':subprocess.check_output(['rustc','-vV'],env=env,text=True)})
result=0
try:
 if a.phase=='compile':
  result,log=run(d/'command',compile_cmd,env)
  if result==0:
   records=[]
   for line in log.splitlines():
    try:v=json.loads(line)
    except json.JSONDecodeError:continue
    if v.get('reason')=='compiler-artifact':records.append(v)
   unit=[v for v in records if v.get('executable') and v.get('target',{}).get('name')=='raw_decode' and 'lib' in v['target']['kind'] and v.get('profile',{}).get('test')]
   assert len(unit)==1
   libs={}
   for crate in ['raw_decode','engine_api']:
    paths={n for v in records if v.get('target',{}).get('name')==crate for n in v.get('filenames',[]) if n.endswith('.rlib')}
    assert len(paths)==1,(crate,paths)
    q=pathlib.Path(paths.pop());libs[crate]={'path':str(q),'sha256':sha(q)}
   q=pathlib.Path(unit[0]['executable']);save(OUT/'artifacts.json',{'head':HEAD,'compile_attempt':a.attempt,'unit':{'path':str(q),'sha256':sha(q)},'libs':libs,'dependency_context':{n:sha(pathlib.Path(n)) for v in records for n in v.get('filenames',[]) if pathlib.Path(n).is_file() and pathlib.Path(n).suffix in ['.rlib','.rmeta','.dylib','.so']}})
 else:
  artifacts=json.loads((OUT/'artifacts.json').read_text());assert artifacts['head']==HEAD
  assert b==json.loads((OUT/artifacts['compile_attempt']/'after.json').read_text())
  for f in [artifacts['unit'],*artifacts['libs'].values()]:assert sha(pathlib.Path(f['path']))==f['sha256']
  assert artifact_context()==artifacts['dependency_context']
  save(d/'artifacts-before.json',artifacts)
  if a.phase=='red':
   cmd=[artifacts['unit']['path'],'capture::tests::decode::owned::','--test-threads=1','--nocapture','--skip','capture::tests::decode::owned::actual_opaque_owner_five_families_after_original_copy_replacement']
   result,log=run(d/'command',cmd,env);names=re.findall(r'^test (\S+) \.\.\.',log,re.M)
   save(d/'observed.json',{'names':names,'summaries':re.findall(r'test result:.*',log),'direct_exit':result,'classification':'manual failure-boundary review; Unsupported failures expected, table rows can remain latent'})
   assert sorted(names)==sorted(json.loads((OUT/'required-tests.json').read_text()))
  else:
   folder=ROOT/'crates/raw-decode/tests/owned_api';expect=json.loads((folder/'expectations.json').read_text());names=['pass.rs']+sorted(n for n in expect if n!='pass.rs');observed={}
   for i,name in enumerate(names):
    cmd=['rustc','--edition=2024','--crate-type=bin','--crate-name','owned_api_control','--emit=metadata','--error-format=json','-L','dependency='+TARGET+'/release/deps']
    for crate,f in artifacts['libs'].items():cmd+=['--extern',crate+'='+f['path']]
    cmd += [str(folder/name),'-o',str(d/(name+'.rmeta'))]
    code,log=run(d/(f'{i:02d}-'+name.removesuffix('.rs')),cmd,env);rule=expect[name]
    diagnostics=[]
    for line in log.splitlines():
     try:v=json.loads(line)
     except json.JSONDecodeError:continue
     if v.get('level')=='error':diagnostics.append(v)
    codes=[v['code']['code'] for v in diagnostics if v.get('code')]
    observed[name]={'exit':code,'codes':codes};save(d/'observed.json',observed)
    if name=='pass.rs':assert code==0,'positive downstream control failed; no negative acceptance'
    else:
     assert code!=0 and codes and set(codes)=={rule['code']},'wrong compiler diagnostic'
     rendered='\n'.join(v.get('rendered','') for v in diagnostics)
     assert all(s in rendered for s in rule['contains']), 'missing intended diagnostic text'
     assert any(any(pathlib.Path(span.get('file_name','')).name==name and span.get('is_primary') for span in v.get('spans',[])) for v in diagnostics if v.get('code')), 'diagnostic not anchored to intended fixture'
   result=0
  after_artifacts={**artifacts,'unit':{**artifacts['unit'],'sha256':sha(pathlib.Path(artifacts['unit']['path']))},'libs':{k:{**v,'sha256':sha(pathlib.Path(v['path']))} for k,v in artifacts['libs'].items()}}
  save(d/'artifacts-after.json',after_artifacts);assert after_artifacts==artifacts;assert artifact_context()==artifacts['dependency_context']
except Exception as error:
 save(d/'oracle-error.json',{'type':type(error).__name__,'message':str(error),'note':'runner/setup oracle failure, not an intended negative compile result'})
 raise
finally:
 after=freeze();save(d/'after.json',after);save(d/'freeze.json',{'equal':b==after,'workload_direct_exit':result});assert after==b
raise SystemExit(result)
