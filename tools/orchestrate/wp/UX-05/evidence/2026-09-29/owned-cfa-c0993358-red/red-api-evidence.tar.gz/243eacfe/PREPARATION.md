# Opaque owner RED/API preparation — UNEXECUTED

Exact243eacfee83a3a2bcce99ff65285e06558fee28f. No actual fixture qualification authorized by this runner. After source review and runtime grant:

    python3 run.py compile --attempt 01-compile --execute
    python3 run.py red --attempt 02-red --execute
    python3 run.py api --attempt 03-api --execute

Compile all raw-decode test binaries without running them, locked/jobs2/Release/sharedtarget/macOS15; parse exact unit binary and raw_decode/engine_api rlib identities from Cargo JSON. Run only five protocol tests (actual ignored test explicitly excluded), preserve direct101 as observed RED and inspect first failing assertions/table limits. API phase then compiles downstream pass.rs successfully before eight exact diagnostic negative controls; rustc --emit metadata does not run binaries/native code. Every intended failure has its own direct compiler exit/log, expected code/text; unresolved crate/import or wrongerror is a harness/test problem, never successful rejection. Wrapper assertions remain distinct from recorded direct compiler/test exits.

All phases freeze source/runner/oracle and relevant binary/rlibs before/after. Fixture environment overrides scrubbed; synthetic temporary bytes only. Private native-invalid-byte test can invoke the existing closed decoder after implementation, but current scaffold remainsUnsupported and no real photo/native fixture is decoded. Positive integration typecheck and negative API boundaries may already pass at scaffold; those are not behavioral RED. Existing old decoder/shared cleanup remains unchanged. No GPU/apps/performance or implementation. Two actual five-family tests remain ignored/unrun and require separate authorization/fixture freeze before any execution. Previous qualified normalization branch/evidence retained.

Runner additionally captures rustc -vV and exact Cargo-emitted transitive rlib/rmeta/proc-macro artifact paths/hashes (no stale glob). Each command/individual downstream fixture captures source and dependency hashes before/after. Negative diagnostic must have a primary span in its intended fixture. Compiler artifacts remain in sharedtarget through this exclusive stage; do not reuse target before recording the final immutable proof.
