#!/usr/bin/env python3
"""Prepared only. Execution needs coordinator's exclusive runtime grant."""
import argparse, hashlib, json, os, pathlib, re, subprocess, time
ROOT=pathlib.Path('/Users/rutmehta/.codex/worktrees/raw-render-admission/tessera')
OUT=pathlib.Path(__file__).parent
HEAD='2fa62cef49d8c679d076cacf7b8ab288c8583617'
ENV={'CARGO_TARGET_DIR':'/Volumes/betterSSD/tessera-cache/target/depth-histogram-readonly-77eb68d0-relocated','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MACOSX_DEPLOYMENT_TARGET':'15.0'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def freeze():
 names=git('ls-files','-z','--cached','--others','--exclude-standard').split('\0')
 return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain'),'source':{n:sha(ROOT/n) for n in names if n and (ROOT/n).is_file()},'runner':sha(pathlib.Path(__file__)),'oracle':sha(OUT/'required-tests.json'),'fixtures':'none; synthetic filtered unit tests only'}
p=argparse.ArgumentParser();p.add_argument('phase',choices=['compile','red']);p.add_argument('--attempt',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
cmd=['cargo','test','--locked','--jobs','2','-p','raw-decode','--release','--lib','normalize::legacy_tests','--no-run'] if a.phase=='compile' else None
if not a.execute:
 print(json.dumps({'phase':a.phase,'argv':cmd or ['<exact compiled executable>','normalize::legacy_tests','--test-threads=1','--nocapture'],'env':ENV,'state':'PREPARED; freeze/workload deferred until grant'}));raise SystemExit(0)
assert re.fullmatch(r'[0-9][A-Za-z0-9_-]*',a.attempt)
d=OUT/a.attempt;d.mkdir(exist_ok=False)
b=freeze();save(d/'before.json',b);assert b['head']==HEAD and not b['status']
artifact=None
if a.phase=='red':
 artifact=json.loads((OUT/'artifact.json').read_text());assert artifact['head']==HEAD;assert sha(pathlib.Path(artifact['path']))==artifact['sha256'];assert b==json.loads((OUT/artifact['compile_attempt']/'after.json').read_text());save(d/'artifact-before.json',artifact)
 cmd=[artifact['path'],'normalize::legacy_tests','--test-threads=1','--nocapture']
env={k:v for k,v in os.environ.items() if not k.startswith(('TESSERA_','RUST_TEST_')) and k not in ['RAW_DECODE_FIXTURES','PIPELINE_RAW_FIXTURES','IMAGE_CORE_ALL_FIXTURES']};env.update(ENV)
save(d/'command.json',{'argv':cmd,'cwd':str(ROOT),'env':ENV,'TESSERA_test_fixture_overrides_scrubbed':True})
start=time.monotonic()
with (d/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
(d/'exit').write_text(str(r.returncode)+'\n');after=freeze();save(d/'after.json',after);save(d/'freeze.json',{'equal':b==after,'direct_exit':r.returncode,'elapsed_seconds':time.monotonic()-start});assert b==after
log=(d/'run.log').read_text()
if a.phase=='compile':
 if r.returncode:raise SystemExit(r.returncode)
 paths=re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)',log);assert len(paths)==1
 exe=pathlib.Path(paths[0]);save(OUT/'artifact.json',{'head':HEAD,'compile_attempt':a.attempt,'path':str(exe),'sha256':sha(exe)})
else:
 current={**artifact,'sha256':sha(pathlib.Path(artifact['path']))};save(d/'artifact-after.json',current);assert artifact==current
 names=json.loads((OUT/'required-tests.json').read_text());observed=re.findall(r'^test (normalize::legacy_tests::\w+) \.\.\.',log,re.M);assert len(observed)==4 and set(observed)==set(names)
 summaries=re.findall(r'test result:.*',log);save(d/'observed.json',{'direct_exit':r.returncode,'names':observed,'summaries':summaries,'classification':'Manual delegation-boundary review required; expectation is 1 missing-delegation failure and 3 existing controls, not asserted by runner'})
 # Preserve behavioral101 as direct status; caller reviews Unsupported boundaries.
 raise SystemExit(r.returncode)
