# Task2 delegation RED

Exact `2fa62cef49d8c679d076cacf7b8ab288c8583617` compile direct0, exact four-test binary direct101: **3 passed,1 failed,0 ignored,87 filtered**. Sole failure at normalize/legacy_tests.rs:118: real helper-entry observation is0, expected1. Independent pixel equality earlier in that same test passed; subsequent input pointer/capacity and uncancelled-token assertions remain unexecuted. Three legacy numerical/admission controls passed. This is missing-delegation RED, not a numerical failure.

All four source/runner/oracle freezes equal (9141 source entries); executable before/after/rehashed identity `84a59909fc462d668e4f6d148062b68408b2a1162b98be3f792ab2050595ee46`. Synthetic-only: no fixture tests, photo reads, GPU or app workload. Direct logs/exits and observed inventory preserved. No source changes or implementation; runtime explicitly released immediately after observation. RED awaits independent review before delegation.
