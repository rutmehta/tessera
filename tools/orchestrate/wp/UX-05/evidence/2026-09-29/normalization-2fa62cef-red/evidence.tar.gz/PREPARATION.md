# Task2 bounded RED runner — prepared, UNRUN

Pinned 2fa62cef49d8c679d076cacf7b8ab288c8583617. After review and exclusive runtime grant only:

    python3 run.py compile --attempt 01-compile --execute
    python3 run.py red --attempt 02-red --execute

Compile --locked/jobs2/release/lib, then execute the exact hashed binary with normalize::legacy_tests --test-threads=1 --nocapture. Shared BetterSSD target and macOS15 explicit; test/fixture environment overrides scrubbed. Before/after source/runner/oracle freezes and direct logs/exits retained. Required exact inventory is four names; observed outcomes are recorded, not forced to the expected split. Expected source-level outcome: one missing-delegation failure and three existing arithmetic/admission controls. Compilation/setup failure is distinct. Later assertions or table rows after failure remain unexecuted.

Synthetic scope only: filtered binary runs no real RAW fixture test; no photo decoding or fixture reads/hashing, GPU/apps, broad tests or implementation. No freeze/build/test execution during preparation. Prior Task1 evidence is preserved in sibling directories.
