# Actual-focus trace qualification plan — PREPARED ONLY

No builds/tests/apps/CUA have run for c5f8bca7. Root must grant exclusive runtime. Do not execute this plan while FFI/cache owns it.

## Automated gates

`python3 run.py 01-focused --attempt 01 --execute` runs Release jobs2, reusing prior scratch with exact frozen858 accepted four FFI artifacts and Sonyfixture.42 named tests are required:10 InspectorFocusTrace +10 KeyFocus +5 DocumentKeyRouting +6 History +11 DocumentVectorVerifyFixes. The known-failed DocumentInspectorFocusRoutingTests is excluded from the checkout, not filtered into a passing aggregate. Preserve direct exits, warnings, skipped/missing tests and source/fixture/artifact freezes. Each gate also snapshots and compares the runner, imported historical run.py dependency, baseline.json and required-tests.json before/after; any mutation fails qualification. Stop on failure before correction; no blind retries.

`python3 run.py 02-strict --attempt 01 --execute` builds Release Tessera with complete strict concurrency and warnings-as-errors. No native regeneration. Preserve final executable separately with exact hash/provenance before packaging. Reused scratch currently contains failed0e64 hosted-diagnostic output, so no --skip-build or claim it already matches c5f8. Prior858 qualified binary and GUI package remain unchanged.

## Separate actual GUI grant, after independent provenance approval

Package only the new preserved strict executable into a new unique bundle; record source/package before/after hashes, relative Frameworks rpath change and signing commands. Reuse approved packaging method, never overwrite old packages. Create a new local owned `/tmp/tessera-inspector-focus-trace-c5f8bca7` profile and copied/generated PNG/LUT/four-layer document, refusing preexisting paths. Do not use user photos or default profile. Record all fixture/document bytes before/after. No global settings, keyboard navigation or protected prompt changes.

Prepare exact paths before launch; example commands (not executed):

```sh
open -n '<new-owned-package>/Tessera Inspector Trace c5f8bca7.app' --args --app-dir '/tmp/tessera-inspector-focus-trace-c5f8bca7/profile'
open -n '<same-new-owned-package>/Tessera Inspector Trace c5f8bca7.app' --args --app-dir '/tmp/tessera-inspector-focus-trace-c5f8bca7/profile' --inspector-focus-trace '/tmp/tessera-inspector-focus-trace-c5f8bca7/evidence/focus-01.jsonl'
```

First trace DISABLED: identify exact ownedPID/args, open owned document via actual native CUA, choose Color Lookup Properties, observe selected document/layer identity and current AX. Click Name, one Tab, observe Load focus, one Tab, observe whether panels hide. Capture the exact steps and fresh visible/AX state. Record observed full keyboard policy only if available; do not modify it. No Space/Return on Load (would open chooser). Restore panel visibility if hidden with one ordinary Tab; do not manufacture focus using APIs. Ordinary Command-Q, then shell anchored exact-package process check only. Never call getApp/getAXState after quit.

Then trace ENABLED: verify new trace output path absent and parent owned/existing. Relaunch same package/profile with exact explicit arguments, repeat identical setup/events. Observe actual external AX and correlate pre-event trace record's window/key/timestamp/semantic role+ID/membership/native responder and handler result. Trace classes are diagnostic only. Repeat reverse ShiftTab only if within bounded trace32events/64KiB. Do not exhaust with exploratory key loops. No document edits or chooser activation.

Unknown/missing/empty/truncated/conflicting semantic records, failed owned-window admission, or enabled-only changed reproduction are inconclusive, not acceptance. Never replace an old trace file or infer a GUI pass from collector unit tests. If behavior changes with tracing, preserve both observations and stop for source diagnosis. History reachable keyboard actions remain separate pending acceptance; this trace is not a correction or VoiceOver qualification.

Ordinary quit owned app, anchored shell absence verification, no CUA afterward. Hash final source executable/package/fixture/document and preserve trace rawbytes/stdout/AX observations, disclosing whether screenshots exist only in the tool transcript. Release runtime explicitly. No product fix, main merge or broad GUI matrix is authorized by this diagnostic plan.
