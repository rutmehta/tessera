# Inspector native AX lifetime qualification

Exact4685efd5:48focused tests passed,0failures/0skips, direct0 (38.78s). Both observed native graph and matched no-observer graph released after explicit autoreleasepool drain while window/returnedSnapshot remain alive. Original47-case failure preserved; this proves no retention beyond the declared boundary, not exact prior internal owner.

Strict Release build complete-concurrency/warnings-as-errors direct0 (126.10s gate,122.95s build). All8392sourceinputs,HEAD,fourFFIartifacts,Sonyfixture,runner/transitive imports+oracles/baseline match before/after. Old unrelated focusedtest warnings remain in rawlog; strict productlog successful. No source corrections or assertion waiver occurred during gates.

Strict output and focusedtest executable preserved under final-binaries; final-artifacts.json records source/copy SHA256. Historical c5f8 GUI observer crash and114273 lifetime failure remain untouched. No GUI launch performed. Actual isolated disabled/enabled Tab trace remains mandatory and must guard originalPID/path/args before each CUA observation after potentially crashing key. No keyboard routing acceptance or leak-cause claim. Runtime lane released for root independent verification.
