#!/usr/bin/env python3
"""Prepared only; --execute requires a fresh root runtime grant."""
import runpy,pathlib,json,subprocess,os,time,argparse,re,hashlib
IMPORTED_RUNNER=pathlib.Path('/Volumes/betterSSD/tessera-validation/b5-16-history-858147a3/run.py')
M=runpy.run_path(str(IMPORTED_RUNNER))
OUT=pathlib.Path(__file__).parent
def qualification_inputs():
 paths=[pathlib.Path(__file__),IMPORTED_RUNNER,IMPORTED_RUNNER.parent/'required-adjacent-full.json',OUT/'required-tests.json',OUT/'required-adjacent.json',OUT/'baseline.json']
 return {str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}

GATES={'03-theme-layout':M['swift']('ThemeLintTests|DocumentInspectorLayoutTests'),'01-focused':M['swift']('DocumentInspectorActionButtonTests|InspectorFocusAXBridgeTests|InspectorFocusTraceTests|KeyFocusTests|DocumentKeyRoutingTests|DocumentHistoryHeightControlTests|DocumentVectorVerifyFixesTests'),'02-strict':['swift','build','--package-path','apps/mac','--scratch-path',str(M['SCRATCH']),'-c','release','--jobs','2','--product','Tessera','-Xswiftc','-strict-concurrency=complete','-Xswiftc','-warnings-as-errors']}
parser=argparse.ArgumentParser();parser.add_argument('gate',choices=GATES);parser.add_argument('--attempt',required=True);parser.add_argument('--execute',action='store_true');args=parser.parse_args()
cmd=GATES[args.gate];overrides=M['ENV'].copy()
if args.gate in ['01-focused','03-theme-layout']:overrides['TESSERA_SMART_PREVIEW_RAW']=str(M['FIXTURE'])
if not args.execute:
 print(json.dumps({'cwd':str(M['ROOT']),'argv':cmd,'env':overrides,'status':'PREPARED ONLY; requires runtime grant'},indent=2));raise SystemExit(0)
p=OUT/(args.gate+'-'+args.attempt);p.mkdir(exist_ok=False)
inputs_before=qualification_inputs()
(p/'qualification-inputs-before.json').write_text(json.dumps(inputs_before,indent=2))
before=M['snapshot']();baseline=json.loads((OUT/'baseline.json').read_text())
for key in ['head','source','ignored_ffi','fixture']:assert before[key]==baseline[key],key
(p/'before.json').write_text(json.dumps(before,indent=2))
runnerhash=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
(p/'command.json').write_text(json.dumps({'cwd':str(M['ROOT']),'argv':cmd,'env':overrides,'runner_sha256':runnerhash,'inherited_TESSERA_removed':True},indent=2))
env={k:v for k,v in os.environ.items() if not k.startswith('TESSERA_')};env.update(overrides)
t=time.monotonic()
with (p/'run.log').open('w') as f:r=subprocess.run(cmd,cwd=M['ROOT'],env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'exit').write_text(str(r.returncode)+'\n')
after=M['snapshot']();(p/'after.json').write_text(json.dumps(after,indent=2))
inputs_after=qualification_inputs()
(p/'qualification-inputs-after.json').write_text(json.dumps(inputs_after,indent=2))
freeze={k+'_equal':before[k]==after[k] for k in ['head','source','ignored_ffi','fixture']};freeze['runner_equal']=runnerhash==hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest();freeze['qualification_inputs_equal']=inputs_before==inputs_after;freeze['elapsed_seconds']=time.monotonic()-t
(p/'freeze.json').write_text(json.dumps(freeze,indent=2));assert all(v for k,v in freeze.items() if k.endswith('_equal'))
if args.gate in ['01-focused','03-theme-layout']:
 log=(p/'run.log').read_text();names=json.loads((OUT/('required-tests.json' if args.gate=='01-focused' else 'required-adjacent.json')).read_text());results={name:[line for line in log.splitlines() if name in line and "' passed" in line] for name in names}
 (p/'required-results.json').write_text(json.dumps(results,indent=2))
 if r.returncode==0:assert all(len(v)==1 for v in results.values()),'missing/skipped required test'
print(json.dumps({'exit':r.returncode,**freeze}));raise SystemExit(r.returncode)
