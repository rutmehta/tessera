# Dither-only actual GUI checkpoint — prepared, not launched

Use the existing exact strict d019 signed package and new explicit local app-dir/fixture/trace paths in PREPARATION.json. Full-test relink executable is NOT used. No launch/CUA/compiler until root explicitly grants the runtime lane. Original LUT acceptance evidence remains untouched.

After launch record original PID, full executable path and exact explicit arguments. Open only the new copied warm-gradient.tessera-doc using native UI, select Color Lookup/Properties, record document identity and original Dither value. Reach Dither by normal keyboard traversal from Name through native Load/Reset, verifying current focus after each step. Do not force first responder or change global keyboard/VoiceOver settings.

At Dither focus, test Tab first. Before any post-event CUA observation, shell-check the original PID/path/args. Capture external AX focus/panel visibility and corresponding raw trace native/semantic/window/handled data. If panels hide, focus is unexpectedly lost, app crashes, or other actual unexpected behavior occurs, STOP this checkpoint: preserve evidence, ordinary quit if the same owned process remains available, shell-only absence; no further Dither/History probes or source correction. Unknown semantic attribution stays unknown.

Only if Tab behaves normally, re-establish actual Dither focus and separately test Shift-Tab with the same guard/recording. Only if both pass, re-establish Dither and press Space, verify checkbox value/visible edit, then one Undo restores it. Do not infer exact callback counts from idempotent or aggregate UI state. Never perform History expansion in this checkpoint.

Ordinary quit only owned app; no CUA after quit. If original PID disappears or arguments change, no CUA observation or re-selection: shell-only crash/process evidence, stop with no relaunch. Afterward compare exact package/strict source/copied fixture hashes, preserve trace and report observed/unrun rows. No global prefs/other apps/user photos.
