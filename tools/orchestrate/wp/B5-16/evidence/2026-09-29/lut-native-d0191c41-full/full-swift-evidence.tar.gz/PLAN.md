# d019 full Swift follow-up — prepared only

No runtime grant yet. FFI owns WB qualification. Current checkout remains clean exact d0191c41859171dc28ef4114891ed4a4c51084b6; no main merge or source changes.

Command after explicit handoff:

`python3 /Volumes/betterSSD/tessera-validation/b5-16-lut-native-d0191c41/full-followup/run.py 04-full --attempt 01 --execute`

Serial Release `swift test`, jobs2, preserved scratch b5-16-history-cd0b850d/swift-build; deployment15, existing BetterSSD Cargo target/jobs2/Rayon2. All inherited TESSERA flags are removed, then exact approved Sony path is explicitly set for both actual SmartPreviewNativeWorkflowTests. No API/archive regeneration. Test-owned temporary fixtures remain test-managed; original Sony is hashed before/after. Performance opt-ins remain disabled and skips must be reported.

155 unique mandatory exact-pass oracles combine every earlier required adjacent/full case, original model/analysis+ShellLayout checks, two actual Sony workflows, all current54 focused cases and current3 ThemeLint/DocumentInspector layout checks. Successful exit alone is insufficient: every oracle must occur once as passed. Full test inventory/counts/skips must also be read from log.

Runner and imported executable code, imported adjacent oracle, local full oracle and baseline are hashed before/after. Source Git inputs/HEAD/four ignored FFI artifacts/Sony must match reviewed baseline and stay equal; outputs are recorded before/after, allowed to relink under this gate. Every attempt uses an exclusive new directory, records direct exit before assertions and preserves failures/logs. No blind retry or source correction without diagnosis.

Preserved strict d019 executable and GUI package remain immutable. If full relinks an executable, capture it under a separate provenance label, never relabel it strict. Prior full858 acceptance does not replace this new full run.
