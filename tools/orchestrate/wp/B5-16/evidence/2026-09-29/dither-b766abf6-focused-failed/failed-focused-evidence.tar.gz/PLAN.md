# Dither candidate b766abf6 — prepared only

Source-only composition of exact five B files from cae6e79d onto qualifiedd019, preserved ref codex/b516-lut-qualified-d0191c41. Branch codex/b516-dither-native-key-owner; clean committed b766abf62ef0c38d977827236bd3de11af048026. Original failed Dither evidence remains immutable.

No runtime until explicit root lane grant. Serial commands:

- `python3 run.py 01-focused --attempt 01 --execute` —60 exact required passes: six new Dither plus prior54LUT/History/trace/bridge/routing.
- `python3 run.py 03-theme-layout --attempt 01 --execute` —3 exact ThemeLint/DocumentInspector layout passes.
- `python3 run.py 02-strict --attempt 01 --execute` —Release product, complete concurrency and warnings-as-errors.

Existing bounded scratch/jobs2/deployment15 and unchangedfourFFI reused; no API regeneration. Every gate verifies source/HEAD/fourFFI/Sony against baseline and before/after; runner/imported executable code/imported oracle/local oracles/baseline hashed each gate. Explicit Sony on test gates, inherited TESSERA flags removed. Direct exit and fullwarnings/rawfailures preserved in exclusiveattemptdirs. Stop unexpected failure before correction. Tests all UNRUN. Full suite requires subsequent separately reviewed grant/mandatory inventory; prior d019 full acceptance is historical for this product delta.

After green preserve exact strict executable and obtain independent provenance review. Only then package unique owned copy with signing/rpath manifest and fresh explicit localprofile/fixture/trace. Actual GUI replays failing Name→Load→Reset→Dither→Tab first; PID/path/args guard before post-event observation; stop first unexpected behavior. If passes, record nativecheckbox responder/semantic distinction, reverse Shift-Tab, Space checkboxchange/onevisibleedit/Undo restoration, disabledReset path and viewport Tab regression. Native Return/keypad convention is not forced action-button behavior. Disk save/reopen persistence and style/AX/held-repeat claims require actual observation; do not infer from hosted test or JSON roundtrip. No History expansion without separategrant. Ordinaryquit/shellabsence, noCUAafterquit, no globalprefs/otherapps/userphotos.
